#include <jni.h>
#include <string>
#include <vector>
#include <cstring>
#include "llama.h"

static llama_model * g_model = nullptr;
static llama_context * g_ctx = nullptr;

extern "C" JNIEXPORT jstring JNICALL
Java_com_localai_app_NativeEngine_load(JNIEnv * env, jclass, jstring jpath, jint n_threads, jint ctx_size) {
    const char * path = env->GetStringUTFChars(jpath, nullptr);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    llama_model_params mp = llama_model_default_params();
    g_model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    if (!g_model) return env->NewStringUTF("Не удалось открыть GGUF-модель");
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t) ctx_size;
    cp.n_threads = n_threads;
    cp.n_threads_batch = n_threads;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) { llama_model_free(g_model); g_model = nullptr; return env->NewStringUTF("Не удалось создать контекст llama.cpp"); }
    return env->NewStringUTF("OK");
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_localai_app_NativeEngine_generate(JNIEnv * env, jclass, jstring jprompt, jint max_tokens) {
    if (!g_model || !g_ctx) return env->NewStringUTF("Сначала загрузи модель");
    const char * prompt = env->GetStringUTFChars(jprompt, nullptr);
    const llama_vocab * vocab = llama_model_get_vocab(g_model);
    int n = llama_tokenize(vocab, prompt, (int) strlen(prompt), nullptr, 0, true, true);
    if (n <= 0) { env->ReleaseStringUTFChars(jprompt, prompt); return env->NewStringUTF("Ошибка токенизации"); }
    std::vector<llama_token> tokens(n);
    n = llama_tokenize(vocab, prompt, (int) strlen(prompt), tokens.data(), n, true, true);
    env->ReleaseStringUTFChars(jprompt, prompt);
    if (n < 0) return env->NewStringUTF("Ошибка токенизации");
    llama_memory_clear(llama_get_memory(g_ctx), true);
    llama_batch batch = llama_batch_get_one(tokens.data(), n);
    if (llama_decode(g_ctx, batch) != 0) return env->NewStringUTF("Ошибка обработки prompt");
    llama_sampler * sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sampler, llama_sampler_init_greedy());
    std::string out;
    const int limit = max_tokens > 0 ? max_tokens : 256;
    for (int i = 0; i < limit; ++i) {
        llama_token id = llama_sampler_sample(sampler, g_ctx, -1);
        if (llama_vocab_is_eog(vocab, id)) break;
        char piece[512];
        int len = llama_token_to_piece(vocab, id, piece, sizeof(piece), 0, true);
        if (len > 0) out.append(piece, len);
        batch = llama_batch_get_one(&id, 1);
        if (llama_decode(g_ctx, batch) != 0) break;
    }
    llama_sampler_free(sampler);
    return env->NewStringUTF(out.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_localai_app_NativeEngine_unload(JNIEnv *, jclass) {
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}
