package com.localai.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import java.util.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    int bg = Color.rgb(0,0,0), panel = Color.rgb(17,17,19), accent = Color.rgb(167,139,250);
    LinearLayout root, messages, drawer;
    EditText prompt;
    TextView modelLabel;
    Uri modelUri, mmprojUri;
    boolean modelLoaded=false;
    String modelPath;
    int ramMb = 2048, threads = Math.max(1, Runtime.getRuntime().availableProcessors()-1);
    final int PICK_MODEL=10, PICK_FILE=11, PICK_MMPROJ=12, PICK_MODULE=13;
    final ArrayList<GGUFModule> ggufModules = new ArrayList<>();
    String selectedMmprojPath = "";

    static class GGUFModule {
        String name, path, kind;
        GGUFModule(String n, String p, String k){ name=n; path=p; kind=k; }
    }

    void loadModuleRegistry(){
        ggufModules.clear();
        android.content.SharedPreferences prefs=getSharedPreferences("gguf_modules",MODE_PRIVATE);
        selectedMmprojPath=prefs.getString("selected_mmproj", "");
        try {
            JSONArray a=new JSONArray(prefs.getString("items", "[]"));
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                String path=o.optString("path", "");
                if(!path.isEmpty() && new java.io.File(path).exists())
                    ggufModules.add(new GGUFModule(o.optString("name", "GGUF module"),path,o.optString("kind","aux")));
            }
        } catch(Exception ignored) {}
    }
    void saveModuleRegistry(){
        JSONArray a=new JSONArray();
        try { for(GGUFModule m:ggufModules){ JSONObject o=new JSONObject(); o.put("name",m.name); o.put("path",m.path); o.put("kind",m.kind); a.put(o); } }
        catch(Exception ignored) {}
        getSharedPreferences("gguf_modules",MODE_PRIVATE).edit().putString("items",a.toString()).putString("selected_mmproj",selectedMmprojPath).apply();
    }
    String moduleKindLabel(String kind){ return "vision".equals(kind)?"Vision projector (mmproj)":"Дополнительная GGUF-модель"; }


    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    GradientDrawable shape(int color, int radius){
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    TextView text(String s,int size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    LinearLayout vertical(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); return l; }
    LinearLayout horizontal(){ LinearLayout l=new LinearLayout(this); l.setOrientation(0); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    TextView button(String label, Runnable action){
        TextView b=text(label,15,Color.WHITE); b.setGravity(Gravity.CENTER); b.setPadding(dp(14),dp(11),dp(14),dp(11));
        b.setBackground(shape(panel,14)); b.setOnClickListener(v->action.run()); return b;
    }
    @Override public void onCreate(Bundle b){ super.onCreate(b); loadModuleRegistry(); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); showChat(); }

    void showChat(){
        root=vertical(); root.setBackgroundColor(bg); setContentView(root);
        LinearLayout top=horizontal(); top.setPadding(dp(14),dp(10),dp(14),dp(10));
        TextView menu=button("☰",()->showDrawer()); top.addView(menu);
        LinearLayout titleBox=vertical(); titleBox.setPadding(dp(12),0,0,0);
        titleBox.addView(text("LOCAL AI",17,Color.WHITE));
        modelLabel=text(modelUri==null?"Модель не выбрана":shortName(modelUri),11,0xFFAAAAAA); titleBox.addView(modelLabel);
        top.addView(titleBox,new LinearLayout.LayoutParams(0,-2,1));
        top.addView(button("⚙",()->showSettings()));
        root.addView(top);
        ScrollView scroll=new ScrollView(this); messages=vertical(); messages.setPadding(dp(14),dp(18),dp(14),dp(18));
        TextView welcome=text("Привет! 👋\n\nЭто твой локальный AI.\n\nДобавь GGUF-модель через меню, чтобы подготовить её к запуску.",17,0xFFE8E8E8);
        welcome.setPadding(dp(16),dp(18),dp(16),dp(18)); welcome.setBackground(shape(panel,18)); messages.addView(welcome);
        scroll.addView(messages); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout composer=horizontal(); composer.setPadding(dp(10),dp(8),dp(10),dp(10)); composer.setBackgroundColor(bg);
        composer.addView(button("+",()->pickFile()),new LinearLayout.LayoutParams(-2,-2));
        prompt=new EditText(this); prompt.setTextColor(Color.WHITE); prompt.setHintTextColor(0xFF888888);
        prompt.setHint("Сообщение..."); prompt.setTextSize(15); prompt.setPadding(dp(12),dp(8),dp(12),dp(8));
        prompt.setBackground(shape(panel,22)); composer.addView(prompt,new LinearLayout.LayoutParams(0,-2,1));
        TextView send=button("➤",()->sendMessage()); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-2,-2); sp.leftMargin=dp(7); composer.addView(send,sp);
        root.addView(composer);
    }
    String shortName(Uri u){ String s=u.getLastPathSegment(); return s==null?"Модель выбрана":s; }
    void addBubble(String s, boolean user){
        TextView t=text(s,15,user?Color.WHITE:0xFFE4E4E4); t.setPadding(dp(14),dp(11),dp(14),dp(11));
        t.setBackground(shape(user?0xFF292333:panel,16));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(user?dp(290):-1,-2); p.gravity=user?Gravity.RIGHT:Gravity.LEFT; p.bottomMargin=dp(10);
        messages.addView(t,p);
    }
    void sendMessage(){
        String s=prompt.getText().toString().trim(); if(s.isEmpty()) return;
        addBubble(s,true); prompt.setText("");
        if(!modelLoaded){ addBubble("Сначала выбери основную GGUF-модель и нажми «Загрузить модель» в меню.",false); }
        else {
            addBubble("Генерирую ответ…",false);
            new Thread(()->{
                String answer;
                try { answer=NativeEngine.generate(s,256); }
                catch(Throwable e){ answer="Ошибка генерации: "+e.getMessage(); }
                final String a=answer;
                runOnUiThread(()->addBubble(a,false));
            }).start();
        }
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(prompt.getWindowToken(),0);
    }
    void showDrawer(){
        final Dialog d=new Dialog(this); LinearLayout box=vertical(); box.setPadding(dp(18),dp(22),dp(18),dp(18)); box.setBackgroundColor(bg);
        box.addView(text("LOCAL AI",21,Color.WHITE)); addGap(box,18);
        box.addView(button("＋  Новый чат",()->{d.dismiss();showChat();})); addGap(box,10);
        box.addView(button("🧠  Выбрать основную GGUF-модель",()->{d.dismiss();pickModel();})); addGap(box,10);
        box.addView(button("🧩  GGUF-модули / плагины",()->{d.dismiss();showModules();})); addGap(box,10);
        box.addView(button("➕  Добавить GGUF-модуль",()->{d.dismiss();pickModule();})); addGap(box,10);
        box.addView(button("👁  Выбрать mmproj (зрение)",()->{d.dismiss();pickMmproj();})); addGap(box,10);
        box.addView(button("▶  Загрузить модель",()->{d.dismiss();loadSelectedModel();})); addGap(box,10);
        box.addView(button("📎  Прикрепить файл или фото",()->{d.dismiss();pickFile();})); addGap(box,10);
        box.addView(button("⚙  Настройки",()->{d.dismiss();showSettings();})); addGap(box,10);
        box.addView(text("История чатов появится после подключения хранилища диалогов.",12,0xFF888888));
        d.setContentView(box); Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(getResources().getDisplayMetrics().widthPixels-dp(48),-1);w.setGravity(Gravity.LEFT|Gravity.TOP);}
        d.show(); if(d.getWindow()!=null){d.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels-dp(48),-1);d.getWindow().setGravity(Gravity.LEFT);}
    }
    void addGap(LinearLayout l,int h){ View v=new View(this); l.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    void pickModel(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK_MODEL);
    }
    void pickMmproj(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK_MMPROJ);
    }
    void pickModule(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK_MODULE);
    }
    void showModules(){
        loadModuleRegistry();
        LinearLayout box=vertical(); box.setPadding(dp(18),dp(18),dp(18),dp(14)); box.setBackgroundColor(bg);
        box.addView(text("GGUF-модули",21,Color.WHITE)); addGap(box,8);
        box.addView(text("Добавляй дополнительные .gguf. Файлы сохраняются в LocalAI и остаются после перезапуска.",12,0xFFAAAAAA)); addGap(box,12);
        if(ggufModules.isEmpty()) box.addView(text("Пока нет добавленных модулей.",14,0xFFBBBBBB));
        for(int n=0;n<ggufModules.size();n++){
            final int index=n; GGUFModule m=ggufModules.get(n);
            LinearLayout row=vertical(); row.setPadding(dp(12),dp(10),dp(12),dp(10)); row.setBackground(shape(panel,12));
            row.addView(text(m.name,15,Color.WHITE));
            row.addView(text(moduleKindLabel(m.kind),12,0xFFAAAAAA));
            if("vision".equals(m.kind)) row.addView(text(m.path.equals(selectedMmprojPath)?"✓ Выбран как mmproj":"Не выбран",12,0xFFB9A6FF));
            LinearLayout actions=horizontal();
            if("vision".equals(m.kind)) actions.addView(button("Выбрать",()->{selectedMmprojPath=m.path;saveModuleRegistry();addBubble("Выбран vision projector: "+m.name+". Для реального анализа изображений нужен MTMD backend в llama.cpp.",false);showModules();}));
            actions.addView(button("Удалить",()->{GGUFModule old=ggufModules.remove(index); if(selectedMmprojPath.equals(old.path))selectedMmprojPath=""; new java.io.File(old.path).delete(); saveModuleRegistry();showModules();}));
            row.addView(actions); box.addView(row); addGap(box,8);
        }
        box.addView(button("＋ Добавить GGUF",()->pickModule()));
        AlertDialog dlg=new AlertDialog.Builder(this).setView(box).setPositiveButton("Закрыть",(a,b)->{}).create(); dlg.show(); if(dlg.getWindow()!=null)dlg.getWindow().setBackgroundDrawable(shape(bg,18));
    }
    void importModule(Uri uri, String kind){
        new Thread(()->{
            try{
                java.io.File dir=new java.io.File(getFilesDir(),"gguf_modules"); if(!dir.exists()&&!dir.mkdirs())throw new Exception("Не удалось создать папку модулей");
                String original=shortName(uri).replaceAll("[^A-Za-z0-9._-]","_");
                if(!original.toLowerCase(Locale.ROOT).endsWith(".gguf"))throw new Exception("Нужен файл с расширением .gguf");
                try(java.io.InputStream check=getContentResolver().openInputStream(uri)){
                    if(check==null)throw new Exception("Не удалось открыть файл");
                    byte[] magic=new byte[4]; if(check.read(magic)!=4 || magic[0]!='G' || magic[1]!='G' || magic[2]!='U' || magic[3]!='F')
                        throw new Exception("Файл не похож на GGUF: неверная сигнатура");
                }
                java.io.File dst=new java.io.File(dir,System.currentTimeMillis()+"_"+original);
                try(java.io.InputStream in=getContentResolver().openInputStream(uri); java.io.OutputStream out=new java.io.FileOutputStream(dst)){
                    if(in==null)throw new Exception("Не удалось открыть файл"); byte[] buf=new byte[1024*1024]; int n; while((n=in.read(buf))!=-1)out.write(buf,0,n);
                }
                runOnUiThread(()->{ggufModules.add(new GGUFModule(original,dst.getAbsolutePath(),kind)); if("vision".equals(kind))selectedMmprojPath=dst.getAbsolutePath(); saveModuleRegistry(); addBubble("GGUF-модуль добавлен: "+original+"\nТип: "+moduleKindLabel(kind),false);showModules();});
            }catch(Exception e){runOnUiThread(()->addBubble("Не удалось добавить модуль: "+e.getMessage(),false));}
        }).start();
    }
    void pickFile(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK_FILE);
    }
    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data); if(res!=RESULT_OK||data==null||data.getData()==null)return;
        Uri u=data.getData(); getContentResolver().takePersistableUriPermission(u,data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
        if(req==PICK_MODEL){
            if(!shortName(u).toLowerCase(Locale.ROOT).endsWith(".gguf")){addBubble("Основная модель должна быть файлом .gguf",false);return;}
            modelUri=u; if(modelLabel!=null)modelLabel.setText(shortName(u)); addBubble("Выбрана основная модель: "+shortName(u),false);
        }
        else if(req==PICK_MMPROJ){
            if(!shortName(u).toLowerCase(Locale.ROOT).endsWith(".gguf")){addBubble("mmproj должен быть файлом .gguf",false);return;}
            importModule(u,"vision");
        }
        else if(req==PICK_MODULE){
            if(!shortName(u).toLowerCase(Locale.ROOT).endsWith(".gguf")){addBubble("Поддерживаются дополнительные файлы .gguf",false);return;}
            new AlertDialog.Builder(this).setTitle("Тип GGUF-модуля").setMessage("Это vision projector mmproj или дополнительная GGUF-модель?")
                .setPositiveButton("Vision / mmproj",(a,b)->importModule(u,"vision"))
                .setNegativeButton("Дополнительная модель",(a,b)->importModule(u,"aux")).show();
        }
        else if(req==PICK_FILE){ addBubble("Прикреплён файл: "+shortName(u)+"\nОбработка содержимого файла пока требует отдельного file-reader модуля.",false); }
    }
    java.io.File copyUriToCache(Uri uri, String name) throws Exception {
        java.io.File dst=new java.io.File(getFilesDir(),name);
        try(java.io.InputStream in=getContentResolver().openInputStream(uri);
            java.io.OutputStream out=new java.io.FileOutputStream(dst)){
            byte[] buf=new byte[1024*1024]; int n;
            while((n=in.read(buf))>0) out.write(buf,0,n);
        }
        return dst;
    }
    void loadSelectedModel(){
        if(modelUri==null){ addBubble("Сначала выбери основную GGUF-модель.",false); return; }
        android.app.ActivityManager.MemoryInfo mi=new android.app.ActivityManager.MemoryInfo();
        ((android.app.ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
        long availableMb=mi.availMem/(1024*1024);
        if(availableMb<1400){ addBubble("Мало свободной RAM: "+availableMb+" МБ. Закрой другие приложения и попробуй снова.",false); return; }
        addBubble("Подготовка модели…",false);
        new Thread(()->{
            try{
                java.io.File f=copyUriToCache(modelUri,"local-model.gguf");
                String result=NativeEngine.load(f.getAbsolutePath(),threads,2048);
                runOnUiThread(()->{ modelLoaded="OK".equals(result); addBubble(modelLoaded?"Модель загружена. Можно задавать вопросы.":result,false); });
            }catch(Exception e){ runOnUiThread(()->addBubble("Ошибка загрузки: "+e.getMessage(),false)); }
        }).start();
    }
    void showSettings(){
        LinearLayout box=vertical(); box.setPadding(dp(20),dp(18),dp(20),dp(12)); box.setBackgroundColor(bg);
        box.addView(text("Настройки производительности",19,Color.WHITE)); addGap(box,12);
        box.addView(text("Оперативная память: "+ramMb+" МБ",15,Color.WHITE));
        SeekBar ram=new SeekBar(this); ram.setMax(6144); ram.setProgress(Math.max(512,ramMb)-512); box.addView(ram);
        ram.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){ramMb=512+p; ((TextView)box.getChildAt(2)).setText("Оперативная память: "+ramMb+" МБ");} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}});
        addGap(box,12); box.addView(text("Потоки CPU: "+threads,15,Color.WHITE));
        SeekBar cpu=new SeekBar(this); cpu.setMax(Math.max(1,Runtime.getRuntime().availableProcessors())); cpu.setProgress(Math.max(0,threads-1)); box.addView(cpu);
        cpu.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){threads=p+1; ((TextView)box.getChildAt(5)).setText("Потоки CPU: "+threads);} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}});
        addGap(box,10); box.addView(text("Важно: лимиты задают параметры будущего движка, но Android может ограничивать фактическую память и загрузку CPU.",12,0xFF999999));
        addGap(box,14); box.addView(button("Выбрать модель GGUF",()->pickModel())); addGap(box,8); box.addView(button("Управление GGUF-модулями",()->showModules()));
        AlertDialog dialog=new AlertDialog.Builder(this).setView(box).setPositiveButton("Готово",(a,b)->{}).create();
        dialog.show(); dialog.getWindow().setBackgroundDrawable(shape(bg,20));
    }
}
