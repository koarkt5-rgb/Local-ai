package com.localai.app;

public final class NativeEngine {
    static { System.loadLibrary("localai"); }
    private NativeEngine() {}
    public static native String load(String modelPath, int threads, int contextSize);
    public static native String generate(String prompt, int maxTokens);
    public static native void unload();
}
