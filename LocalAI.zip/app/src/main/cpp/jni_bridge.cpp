#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <string>
#include <vector>
#include <algorithm>
#include "llama.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "LocalAI", __VA_ARGS__)

static std::atomic<bool> g_stop{false};
static bool g_inited = false;

static std::string fromBytes(JNIEnv* env, jbyteArray arr) {
    if (!arr) return "";
    jsize n = env->GetArrayLength(arr);
    std::string s((size_t)n, '\0');
    if (n > 0) env->GetByteArrayRegion(arr, 0, n, reinterpret_cast<jbyte*>(&s[0]));
    return s;
}

static jbyteArray toBytes(JNIEnv* env, const std::string& s) {
    jbyteArray a = env->NewByteArray((jsize)s.size());
    if (!s.empty()) env->SetByteArrayRegion(a, 0, (jsize)s.size(), reinterpret_cast<const jbyte*>(s.data()));
    return a;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_localai_app_LlamaBridge_loadModel(JNIEnv* env, jclass, jstring jpath) {
    if (!g_inited) { llama_backend_init(); g_inited = true; }
    const char* p = env->GetStringUTFChars(jpath, nullptr);
    std::string path(p);
    env->ReleaseStringUTFChars(jpath, p);
    llama_model_params mp = llama_model_default_params();
    mp.use_mmap = true;
    mp.n_gpu_layers = 0;
    llama_model* m = llama_model_load_from_file(path.c_str(), mp);
    LOGI("loadModel %s -> %p", path.c_str(), (void*)m);
    return reinterpret_cast<jlong>(m);
}

extern "C" JNIEXPORT void JNICALL
Java_com_localai_app_LlamaBridge_freeModel(JNIEnv*, jclass, jlong h) {
    if (h) llama_model_free(reinterpret_cast<llama_model*>(h));
}

extern "C" JNIEXPORT void JNICALL
Java_com_localai_app_LlamaBridge_stop(JNIEnv*, jclass) { g_stop = true; }

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_localai_app_LlamaBridge_applyTemplate(JNIEnv* env, jclass, jlong h, jobjectArray roles, jobjectArray contents) {
    llama_model* model = reinterpret_cast<llama_model*>(h);
    if (!model) return nullptr;
    jsize n = env->GetArrayLength(roles);
    std::vector<std::string> r((size_t)n), c((size_t)n);
    std::vector<llama_chat_message> msgs((size_t)n);
    for (jsize i = 0; i < n; i++) {
        jbyteArray ra = (jbyteArray)env->GetObjectArrayElement(roles, i);
        jbyteArray ca = (jbyteArray)env->GetObjectArrayElement(contents, i);
        r[i] = fromBytes(env, ra);
        c[i] = fromBytes(env, ca);
        env->DeleteLocalRef(ra);
        env->DeleteLocalRef(ca);
    }
    for (jsize i = 0; i < n; i++) { msgs[i].role = r[i].c_str(); msgs[i].content = c[i].c_str(); }

    const char* tmpl = llama_model_chat_template(model, nullptr);
    std::vector<const char*> candidates;
    if (tmpl) candidates.push_back(tmpl);
    candidates.push_back("chatml");

    for (const char* t : candidates) {
        std::vector<char> buf(8192);
        int32_t ret = llama_chat_apply_template(t, msgs.data(), msgs.size(), true, buf.data(), (int32_t)buf.size());
        if (ret > (int32_t)buf.size()) {
            buf.resize((size_t)ret + 16);
            ret = llama_chat_apply_template(t, msgs.data(), msgs.size(), true, buf.data(), (int32_t)buf.size());
        }
        if (ret >= 0) return toBytes(env, std::string(buf.data(), (size_t)ret));
    }
    return nullptr;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_localai_app_LlamaBridge_generate(JNIEnv* env, jclass, jlong h, jbyteArray jprompt,
                                          jint nCtx, jint nThreads, jint maxNew, jfloat temp, jobject cb) {
    g_stop = false;
    llama_model* model = reinterpret_cast<llama_model*>(h);
    if (!model) return env->NewStringUTF("model is null");
    const llama_vocab* vocab = llama_model_get_vocab(model);
    std::string prompt = fromBytes(env, jprompt);

    int n = -llama_tokenize(vocab, prompt.c_str(), (int32_t)prompt.size(), nullptr, 0, true, true);
    if (n <= 0) return env->NewStringUTF("tokenize failed");
    std::vector<llama_token> toks((size_t)n);
    if (llama_tokenize(vocab, prompt.c_str(), (int32_t)prompt.size(), toks.data(), n, true, true) < 0)
        return env->NewStringUTF("tokenize failed");

    if (n >= nCtx - 16) {
        std::string e = "Промпт слишком длинный: " + std::to_string(n) + " токенов при контексте " +
                        std::to_string(nCtx) + ". Очистите чат или увеличьте RAM.";
        return env->NewStringUTF(e.c_str());
    }
    int allowed = std::min((int)maxNew, (int)nCtx - n);

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t)nCtx;
    cp.n_batch = (uint32_t)nCtx;
    cp.n_threads = nThreads;
    cp.n_threads_batch = nThreads;
    llama_context* ctx = llama_init_from_model(model, cp);
    if (!ctx) return env->NewStringUTF("Не хватило памяти для контекста (уменьшите RAM-бюджет или возьмите модель поменьше)");

    llama_sampler* smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.95f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    jclass cbIface = env->FindClass("com/localai/app/LlamaBridge$TokenCallback");
    jmethodID mid = env->GetMethodID(cbIface, "onToken", "([B)V");

    std::string err;
    llama_batch batch = llama_batch_get_one(toks.data(), (int32_t)toks.size());
    llama_token id = 0;
    for (int i = 0; i < allowed && !g_stop.load(); i++) {
        if (llama_decode(ctx, batch) != 0) { err = "llama_decode failed"; break; }
        id = llama_sampler_sample(smpl, ctx, -1);
        if (llama_vocab_is_eog(vocab, id)) break;
        char buf[256];
        int len = llama_token_to_piece(vocab, id, buf, (int32_t)sizeof(buf), 0, true);
        if (len > 0) {
            jbyteArray a = env->NewByteArray(len);
            env->SetByteArrayRegion(a, 0, len, reinterpret_cast<const jbyte*>(buf));
            env->CallVoidMethod(cb, mid, a);
            env->DeleteLocalRef(a);
        }
        batch = llama_batch_get_one(&id, 1);
    }

    llama_sampler_free(smpl);
    llama_free(ctx);
    return env->NewStringUTF(err.c_str());
}
