package com.localai.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_MODEL = 1;
    private static final int REQ_FILE = 2;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Set<String> checked = new LinkedHashSet<>();
    private final List<String[]> attachments = new ArrayList<>();
    private final Map<String, List<String[]>> history = new ConcurrentHashMap<>();

    private LinearLayout modelsBox;
    private TextView status, ramLabel, thrLabel, attachLabel, chat;
    private ScrollView chatScroll;
    private EditText input;
    private Button sendBtn;
    private SeekBar ramBar, thrBar;
    private long totalMb;
    private int cores;
    private String done = "";
    private volatile boolean busy = false;
    private volatile boolean cancel = false;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private File modelsDir() {
        File d = new File(getFilesDir(), "models");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private int ramMb() { return 512 + ramBar.getProgress() * 256; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        totalMb = mi.totalMem / (1024 * 1024);
        cores = Math.max(1, Runtime.getRuntime().availableProcessors());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(10), dp(10), dp(10));

        // ---- settings block (scrollable) ----
        ScrollView settingsScroll = new ScrollView(this);
        LinearLayout settings = new LinearLayout(this);
        settings.setOrientation(LinearLayout.VERTICAL);
        settingsScroll.addView(settings);
        root.addView(settingsScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(250)));

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        Button addModel = new Button(this);
        addModel.setText("+ Модель");
        Button addFile = new Button(this);
        addFile.setText("+ Файл");
        Button clear = new Button(this);
        clear.setText("Очистить");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        btnRow.addView(addModel, bp);
        btnRow.addView(addFile, bp);
        btnRow.addView(clear, bp);
        settings.addView(btnRow);

        ramLabel = new TextView(this);
        settings.addView(ramLabel);
        ramBar = new SeekBar(this);
        long steps = Math.max(1, (totalMb - 512) / 256);
        ramBar.setMax((int) steps);
        long def = (long) (totalMb * 0.6);
        int defProg = (int) Math.max(0, Math.min(steps, (def - 512) / 256));
        ramBar.setProgress(defProg);
        settings.addView(ramBar);

        thrLabel = new TextView(this);
        settings.addView(thrLabel);
        thrBar = new SeekBar(this);
        thrBar.setMax(Math.max(1, cores - 1));
        thrBar.setProgress(Math.min(4, cores) - 1);
        settings.addView(thrBar);

        TextView mh = new TextView(this);
        mh.setText("Модели (отметьте одну или несколько):");
        mh.setPadding(0, dp(8), 0, 0);
        settings.addView(mh);
        modelsBox = new LinearLayout(this);
        modelsBox.setOrientation(LinearLayout.VERTICAL);
        settings.addView(modelsBox);

        attachLabel = new TextView(this);
        attachLabel.setPadding(0, dp(8), 0, 0);
        settings.addView(attachLabel);

        status = new TextView(this);
        status.setPadding(0, dp(4), 0, dp(4));
        root.addView(status);

        // ---- chat ----
        chatScroll = new ScrollView(this);
        chat = new TextView(this);
        chat.setTextSize(15f);
        chat.setPadding(dp(4), dp(4), dp(4), dp(4));
        chatScroll.addView(chat);
        root.addView(chatScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // ---- input ----
        LinearLayout inRow = new LinearLayout(this);
        inRow.setOrientation(LinearLayout.HORIZONTAL);
        inRow.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setHint("Сообщение…");
        input.setMaxLines(5);
        sendBtn = new Button(this);
        sendBtn.setText("Отправить");
        inRow.addView(input, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        inRow.addView(sendBtn);
        root.addView(inRow);

        setContentView(root);

        SeekBar.OnSeekBarChangeListener l = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) { updateLabels(); }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        };
        ramBar.setOnSeekBarChangeListener(l);
        thrBar.setOnSeekBarChangeListener(l);

        addModel.setOnClickListener(v -> pick(REQ_MODEL, false));
        addFile.setOnClickListener(v -> pick(REQ_FILE, true));
        clear.setOnClickListener(v -> {
            history.clear();
            done = "";
            chat.setText("");
            setStatus("Чат очищен");
        });
        sendBtn.setOnClickListener(v -> send());

        updateLabels();
        updateAttach();
        refreshModels();
        setStatus("Готово. Добавьте .gguf модель кнопкой «+ Модель».");
    }

    private void updateLabels() {
        ramLabel.setText("RAM-бюджет: " + ramMb() + " МБ (всего на устройстве: " + totalMb + " МБ)");
        thrLabel.setText("Потоки CPU: " + (thrBar.getProgress() + 1) + " из " + cores);
    }

    private void updateAttach() {
        if (attachments.isEmpty()) {
            attachLabel.setText("Прикреплённых файлов нет");
        } else {
            StringBuilder sb = new StringBuilder("📎 ");
            for (int i = 0; i < attachments.size(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(attachments.get(i)[0]);
            }
            attachLabel.setText(sb.toString());
        }
    }

    private void setStatus(String s) {
        ui.post(() -> status.setText(s));
    }

    private void refreshModels() {
        modelsBox.removeAllViews();
        File[] fs = modelsDir().listFiles((d, n) -> n.endsWith(".gguf"));
        if (fs == null || fs.length == 0) {
            TextView t = new TextView(this);
            t.setText("Моделей нет — нажмите «+ Модель» и выберите файл .gguf");
            modelsBox.addView(t);
            return;
        }
        Arrays.sort(fs);
        Set<String> existing = new HashSet<>();
        for (File f : fs) existing.add(f.getName());
        checked.retainAll(existing);
        if (checked.isEmpty() && fs.length == 1) checked.add(fs[0].getName());

        for (final File f : fs) {
            final String name = f.getName();
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            CheckBox cb = new CheckBox(this);
            cb.setText(name + "  (" + (f.length() >> 20) + " МБ)");
            cb.setChecked(checked.contains(name));
            cb.setOnCheckedChangeListener((b, c) -> {
                if (c) checked.add(name); else checked.remove(name);
            });
            Button del = new Button(this);
            del.setText("✕");
            del.setOnClickListener(v -> {
                if (busy) { Toast.makeText(this, "Дождитесь окончания генерации", Toast.LENGTH_SHORT).show(); return; }
                f.delete();
                history.remove(name);
                checked.remove(name);
                refreshModels();
            });
            row.addView(cb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(del);
            modelsBox.addView(row);
        }
    }

    private void pick(int req, boolean multiple) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        if (multiple) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, req);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        List<Uri> uris = new ArrayList<>();
        ClipData cd = data.getClipData();
        if (cd != null) {
            for (int i = 0; i < cd.getItemCount(); i++) uris.add(cd.getItemAt(i).getUri());
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        for (Uri u : uris) {
            if (req == REQ_MODEL) importModel(u);
            else if (req == REQ_FILE) attachFile(u);
        }
    }

    private String displayName(Uri uri) {
        String name = null;
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) {}
        if (name == null || name.isEmpty()) name = "file_" + System.currentTimeMillis();
        return name;
    }

    private void importModel(final Uri uri) {
        String raw = displayName(uri).replaceAll("[^A-Za-z0-9._-]", "_");
        if (!raw.endsWith(".gguf")) raw = raw + ".gguf";
        final String name = raw;
        setStatus("Копирую модель " + name + "…");
        exec.execute(() -> {
            File out = new File(modelsDir(), name);
            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[1 << 20];
                long tot = 0, lastBucket = -1;
                int n;
                while ((n = in.read(buf)) != -1) {
                    os.write(buf, 0, n);
                    tot += n;
                    long bucket = (tot >> 20) / 64;
                    if (bucket != lastBucket) {
                        lastBucket = bucket;
                        setStatus("Копирую " + name + ": " + (tot >> 20) + " МБ…");
                    }
                }
            } catch (Exception e) {
                out.delete();
                setStatus("Ошибка копирования: " + e.getMessage());
                return;
            }
            ui.post(() -> {
                checked.add(name);
                refreshModels();
                status.setText("Модель добавлена: " + name);
            });
        });
    }

    private void attachFile(final Uri uri) {
        final String name = displayName(uri);
        exec.execute(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1 && b.size() < 200000) b.write(buf, 0, n);
                String t = new String(b.toByteArray(), StandardCharsets.UTF_8);
                if (t.length() > 40000) t = t.substring(0, 40000) + "\n…[обрезано]";
                final String ft = t;
                ui.post(() -> {
                    attachments.add(new String[]{name, ft});
                    updateAttach();
                });
            } catch (Exception e) {
                setStatus("Не удалось прочитать файл: " + e.getMessage());
            }
        });
    }

    private void appendDone(final String s) {
        ui.post(() -> {
            done = done + s;
            chat.setText(done);
            scrollDown();
        });
    }

    private void scrollDown() {
        chatScroll.post(() -> chatScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void send() {
        if (busy) {
            cancel = true;
            LlamaBridge.stop();
            return;
        }
        String text = input.getText().toString().trim();
        if (text.isEmpty() && attachments.isEmpty()) return;
        final List<String> sel = new ArrayList<>(checked);
        if (sel.isEmpty()) {
            Toast.makeText(this, "Отметьте хотя бы одну модель", Toast.LENGTH_SHORT).show();
            return;
        }
        StringBuilder um = new StringBuilder();
        StringBuilder names = new StringBuilder();
        for (String[] a : attachments) {
            um.append("[Файл: ").append(a[0]).append("]\n").append(a[1]).append("\n\n");
            if (names.length() > 0) names.append(", ");
            names.append(a[0]);
        }
        um.append(text);
        final String userMsg = um.toString();

        appendDone("\nВы: " + text + (names.length() > 0 ? "\n📎 " + names : "") + "\n");
        input.setText("");
        attachments.clear();
        updateAttach();

        busy = true;
        cancel = false;
        sendBtn.setText("■ Стоп");
        final int ram = ramMb();
        final int threads = thrBar.getProgress() + 1;
        exec.execute(() -> runAll(sel, userMsg, ram, threads));
    }

    private void runAll(List<String> sel, String userMsg, int ramMb, int threads) {
        for (String name : sel) {
            if (cancel) break;
            File f = new File(modelsDir(), name);
            if (!f.exists()) continue;
            appendDone("\n▶ " + name + "\n");
            setStatus("Загружаю " + name + "…");

            long modelMb = f.length() >> 20;
            long kvMb = ramMb - modelMb;
            int nCtx = (int) Math.max(512, Math.min(8192, kvMb * 3));
            String warn = kvMb < 0 ? " (RAM меньше модели — будет медленно)" : "";

            long h = LlamaBridge.loadModel(f.getAbsolutePath());
            if (h == 0) {
                appendDone("⚠ Не удалось загрузить модель (не тот формат GGUF или не хватает памяти)\n");
                continue;
            }
            try {
                List<String[]> hist = history.get(name);
                if (hist == null) {
                    hist = new CopyOnWriteArrayList<>();
                    history.put(name, hist);
                }
                List<String[]> msgs = new ArrayList<>(hist);
                msgs.add(new String[]{"user", userMsg});
                byte[][] roles = new byte[msgs.size()][];
                byte[][] contents = new byte[msgs.size()][];
                for (int i = 0; i < msgs.size(); i++) {
                    roles[i] = msgs.get(i)[0].getBytes(StandardCharsets.UTF_8);
                    contents[i] = msgs.get(i)[1].getBytes(StandardCharsets.UTF_8);
                }
                byte[] prompt = LlamaBridge.applyTemplate(h, roles, contents);
                if (prompt == null) {
                    appendDone("⚠ Не удалось применить шаблон чата\n");
                    continue;
                }
                setStatus("Генерирую: " + name + " · контекст " + nCtx + " ток." + warn);

                final ByteArrayOutputStream baos = new ByteArrayOutputStream();
                LlamaBridge.TokenCallback cb = bytes -> {
                    baos.write(bytes, 0, bytes.length);
                    final String live = new String(baos.toByteArray(), StandardCharsets.UTF_8);
                    ui.post(() -> {
                        chat.setText(done + live);
                        scrollDown();
                    });
                };
                String err = LlamaBridge.generate(h, prompt, nCtx, threads, 512, 0.7f, cb);
                final String reply = new String(baos.toByteArray(), StandardCharsets.UTF_8);
                appendDone(reply + "\n");
                if (err != null && !err.isEmpty()) {
                    appendDone("⚠ " + err + "\n");
                } else {
                    hist.add(new String[]{"user", userMsg});
                    hist.add(new String[]{"assistant", reply});
                }
            } finally {
                LlamaBridge.freeModel(h);
            }
        }
        ui.post(() -> {
            busy = false;
            sendBtn.setText("Отправить");
            status.setText(cancel ? "Остановлено" : "Готово");
        });
    }
}
