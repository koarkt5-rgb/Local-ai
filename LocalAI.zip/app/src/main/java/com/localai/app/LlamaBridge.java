package com.localai.app;

public final class LlamaBridge {
    static { System.loadLibrary("localai"); }

    public interface TokenCallback { void onToken(byte[] bytes); }

    public static native long loadModel(String path);
    public static native void freeModel(long handle);
    public static native byte[] applyTemplate(long handle, byte[][] roles, byte[][] contents);
    public static native String generate(long handle, byte[] prompt, int nCtx, int threads,
                                         int maxNew, float temp, TokenCallback cb);
    public static native void stop();

    private LlamaBridge() {}
}
